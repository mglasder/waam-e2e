# TODO Load from package
__version__ = "0.0.1-dev"
