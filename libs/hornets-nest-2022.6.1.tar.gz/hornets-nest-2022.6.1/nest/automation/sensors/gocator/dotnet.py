import sys
from typing import Any, Dict

from nest.automation.sensors.gocator import GocatorError, GocatorSensor, GocatorSurface
from nest.automation.sensors.gocator.dlls import gocator_dotnet_dlls
from nest.engineering.ddd import ValueObject


# TODO Replace ValueObject with Config class
class DotnetGocatorConfig(ValueObject):
    ip_address = "129.132.219.77"

    dotnet_paths = gocator_dotnet_dlls

    measurement_try_outs = 3


class DotnetGocatorSensor(GocatorSensor):
    def __init__(self, config: DotnetGocatorConfig = None):
        self._config = config if config else DotnetGocatorConfig()

    def _create_dotnet_client(self):
        sys.path.extend(self._config.dotnet_paths)

        import clr

        clr.AddReference("GocatorScan")

        from GocatorScan import GocatorAPI

        return GocatorAPI()

    def measure(self, parameters: Dict[str, Any] = None):
        for _ in range(self._config.measurement_try_outs):
            try:
                return self._try_measure(parameters)
            except Exception as ex:
                self.logger.error("Failed during scan", ex)

        raise GocatorError(f"Failed {self._config.measurement_try_outs} times to capture")

    def _try_measure(self, parameters):
        client = self._create_dotnet_client()
        client.Init(self._config.ip_address)

        client.Start()
        try:
            dotnet_measurement = client.Measure()
            return self._dotnet_to_measure(dotnet_measurement, parameters)
        finally:
            client.Stop()

    def _dotnet_to_measure(self, obj, parameters):
        return GocatorSurface(
            height_map=list(obj.HeightMap),
            intensity=list(obj.Intensity),
            resolution=list(obj.Resolution),
            width=obj.Width,
            length=obj.Length,
            exposures=list(obj.Exposures),
            parameters=parameters if parameters else {},
        )
