from abc import ABCMeta, abstractmethod
from typing import Any, Dict, List

import numpy as np

from nest.engineering.ddd import Service, ValueObject
from nest.engineering.geometry import Matrix


class GocatorError(Exception):
    pass


class GocatorSurface(ValueObject):
    height_map: List[float]
    intensity: List[float]
    resolution: List[float]
    width: int
    length: int
    exposures: List[int] = []
    parameters: Dict[str, Any] = {}

    def as_matrix(self):
        return Matrix.array(self.resolution[-1] * np.array(self.height_map).reshape((self.length, self.width)))


class GocatorSensor(Service, metaclass=ABCMeta):
    @abstractmethod
    def measure(self, parameters: Dict[str, Any] = None) -> GocatorSurface:
        raise NotImplementedError
