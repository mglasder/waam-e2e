from pathlib import Path
from typing import Optional

import typer

from nest.automation.sensors.gocator import GocatorSurface
from nest.automation.sensors.gocator.dotnet import DotnetGocatorSensor
from nest.automation.sensors.gocator.simulator import SimulatedGocatorSensor
from nest.engineering.app import Application

app = Application(
    name="Gocator",
)


def _create_gocator_sensor(simulate: bool):
    if simulate:
        return app.di.create(SimulatedGocatorSensor, width=100, length=200)
    else:
        return app.di.create(DotnetGocatorSensor)


@app.cli.command()
def scan(output: Path, simulate: Optional[bool] = False):
    gocator = _create_gocator_sensor(simulate)

    surface = gocator.measure()

    surface.write_file(output)

    typer.echo(f"Acquired {surface.width} by {surface.length} surface with resolution {surface.resolution}")


@app.cli.command()
def show():
    # TODO Find a better library than Open3D to visualize
    pass


@app.cli.command()
def convert(input: Path, output: Path):
    surface = GocatorSurface.read_file(input)
    surface.write_file(output)


def main():
    app.cli()


if __name__ == "__main__":
    main()
