from nest.engineering.utils import path_from_package

gocator_dotnet_dlls = [str(path_from_package(__package__))]
