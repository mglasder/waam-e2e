from typing import Any, Dict

import numpy as np

from nest.automation.sensors.gocator import GocatorSensor, GocatorSurface


class SimulatedGocatorSensor(GocatorSensor):
    def __init__(self, width=1103, length=1553):
        self.width = width
        self.length = length

    def start(self):
        # Nothing to do
        pass

    def stop(self):
        # Nothing to do
        pass

    def measure(self, parameters: Dict[str, Any] = None):
        count = self.width * self.length
        # TODO Read from file?
        return GocatorSurface(
            height_map=np.random.normal(loc=500, scale=50, size=count).tolist(),
            intensity=np.random.normal(loc=500, scale=5, size=count).tolist(),
            resolution=[0.1, 0.1, 0.003],
            width=self.width,
            length=self.length,
            exposures=[8000, 30000],
            parameters=parameters if parameters else {},
        )
