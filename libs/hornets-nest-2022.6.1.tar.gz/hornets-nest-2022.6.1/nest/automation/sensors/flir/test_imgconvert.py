import json

import numpy as np
import pandas as pd
import pytest
from assertpy import assert_that

from nest.automation.sensors.flir.fixtures import path
from nest.automation.sensors.flir.imgconvert import (
    FlirTemperatureConversionParameters,
    extract_float,
    get_temperature_conversion_parameters,
)


# TODO Find out why this tests takes that long
@pytest.mark.timeout(20)
@pytest.mark.skip("TODO Find out why this test fails")
def test_get_temperature_data_from_jpeg():
    temperatures = pd.read_csv(path / "temps.csv", header=None).transpose()
    expected = np.reshape(temperatures.values, (348, 464))

    from nest.automation.sensors.flir.imgconvert import FlirImageExtractor
    from nest.automation.sensors.flir.rest import get_exiftool_path

    fie = FlirImageExtractor(get_exiftool_path())
    actual = fie.get_thermal_image(path / "flir.JPEG")

    np.testing.assert_allclose(actual, expected, atol=0.05)


def test_get_temperature_conversion_data_from_exif():
    expected = FlirTemperatureConversionParameters(
        Emissivity=0.95,
        ObjectDistance=1,
        ReflectedApparentTemperature=20,
        AtmosphericTemperature=20,
        InfraRedWindowTemperature=20,
        InfraRedWindowTransmission=1,
        RelativeHumidity=50,
        PlanckR1=19558.744,
        PlanckB=1431.9,
        PlanckF=1.05,
        PlanckO=-3458,
        PlanckR2=0.016656484,
        AtmosphericTransmissionAlpha1=0,
        AtmosphericTransmissionAlpha2=0,
        AtmosphericTransmissionBeta1=0.003180,
        AtmosphericTransmissionBeta2=0.003180,
        AtmosphericTransmissionX=0.732,
    )
    with open(path / "flir_exif.json", "rb") as file:
        exif = json.load(file)
    actual = get_temperature_conversion_parameters(exif)

    assert_that(actual).is_equal_to(expected)


def test_get_float_from_string_with_unit():
    assert_that(extract_float("23.5 C")).is_equal_to(23.5)


def test_get_int_from_string_with_unit():
    assert_that(extract_float("12 m")).is_equal_to(12.0)
