import random

from nest.automation.sensors.flir import FlirSensor, FlirThermalImage
from nest.automation.sensors.flir.rest import RestFlirConfig


class SimulatedFlirSensor(FlirSensor):
    def __init__(self, config: RestFlirConfig = None):
        self._config = config if config else RestFlirConfig()

    def capture(self) -> FlirThermalImage:
        width = 500
        height = 500

        return FlirThermalImage(
            temperature_map=[random.randrange(255) for _ in range(width * height)],
            height=height,
            width=width,
        )
