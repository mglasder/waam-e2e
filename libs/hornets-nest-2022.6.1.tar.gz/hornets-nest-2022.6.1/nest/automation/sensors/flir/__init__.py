from abc import ABCMeta, abstractmethod
from typing import List

from nest.engineering.ddd import Service, ValueObject


class FlirError(Exception):
    pass


class FlirThermalImage(ValueObject):
    temperature_map: List[float]
    width: int
    height: int


class FlirSensor(Service, metaclass=ABCMeta):
    @abstractmethod
    def capture(self) -> FlirThermalImage:
        raise NotImplementedError
