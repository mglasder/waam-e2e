import os
import shutil
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import numpy as np

from nest.automation.sensors.flir import FlirError, FlirSensor, FlirThermalImage
from nest.automation.sensors.flir.imgconvert import FlirImageExtractor
from nest.engineering.config import BaseConfig


class RestFlirConfig(BaseConfig):
    ip = "192.168.0.100"
    measurement_try_outs = 3


class RestFlirSensor(FlirSensor):
    """
    ## API docs
    https://flir.custhelp.com/app/answers/detail/a_id/3602/kw/rest%20api

    ## Camera manual
    https://support.flir.com/DocDownload/Assets/dl/t810579-en-us.pdf
    """

    def __init__(self, config: RestFlirConfig = None):
        self._config = config if config else RestFlirConfig()

    def capture(self) -> FlirThermalImage:
        for _ in range(self._config.measurement_try_outs):
            try:
                return self._try_capture()
            except Exception as ex:
                self.logger.error("Failed to capture image", ex)

        raise FlirError(
            f"Failed to find a FLIR camera at {self._config.ip} after {self._config.measurement_try_outs} tries."
        )

    def _try_capture(self) -> FlirThermalImage:
        url = f"http://{self._config.ip}/api/image/current?imformat=JPEG"
        # TODO check if this can be done by not saving to local file
        filename, _ = urllib.request.urlretrieve(url, "flir.JPEG")

        fl = FlirImageExtractor(exiftool_path=get_exiftool_path())
        # Accuracy of the camera is +/- 2 °C, but rounding to 1 decimal for nicer image
        thermal_image = fl.get_thermal_image(filename).round(decimals=1)
        height, width = thermal_image.shape

        os.remove(filename)

        return FlirThermalImage(
            temperature_map=np.reshape(thermal_image, height * width).tolist(), height=height, width=width
        )


def get_exiftool_path() -> Path:
    if exiftool := shutil.which("exiftool"):
        return Path(exiftool)
    elif "CONDA_PREFIX" in os.environ:
        exiftool = "exiftool.bat" if sys.platform == "win32" else "exiftool"
        return Path(os.environ["CONDA_PREFIX"]) / "bin" / exiftool
    else:
        return Path("/") / "opt" / "conda" / "envs" / "nest39" / "bin" / "exiftool"
