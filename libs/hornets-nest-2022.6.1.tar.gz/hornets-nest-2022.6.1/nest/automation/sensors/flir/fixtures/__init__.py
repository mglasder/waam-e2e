from nest.engineering.utils import path_from_package

path = path_from_package(__package__)
