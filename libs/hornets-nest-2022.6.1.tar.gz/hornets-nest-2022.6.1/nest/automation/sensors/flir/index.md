# FLIR command line interface (CLI)

After successfully installing nest, the `flir` application should be available from your terminal.

## Setup

1. Create a `config.yml` file in the folder where you want to run the script from.
2. Open the `config.yml` file you just created and add a line where you enter the ip of the flir camera, e.g. `ip: 192.168.1.123`. To find the ip of the camera see [here](../../../../infrastructure/equipments/flir/index.md#setup). See the full list of options [here](#configyml).
3. Activate the nest conda virtual environment with `conda activate nest39`
4. Run `conda install exiftool` to install the [exiftool](https://exiftool.org/). Exiftool is needed to read out the temperature data from the thermal camera images.

## `config.yml`

Example config file with all possible settings.

```yml
ip: 192.168.0.183  # The IP of the FLIR camera
measurement_try_outs: 2  # how often the program should try to connect to the camera before exiting
```

## Usage

1. Run `flir capture thermal_image.json` to capture a thermal image and save it into `thermal_image.json`.
2. Run `flir show thermal_image.json` to view the image which was just captured.

The json file contains the temperatures in degrees Celsius and the dimensions of the captured image:

```json
{"temperature_map":[24.2,24.0,23.9,23.9,23.9,..., 23.2],"width":464,"height":348}
```

### Process data in Python

If you would like to load the raw data from the json file you can do that as follows:

```python
import numpy as np
import matplotlib.pyplot as plt
from nest.automation.sensors import FlirThermalImage

thermal_json = FlirThermalImage.parse_file("path/to/thermal_image.json")

# reshape the temperature_map to the correct height and width
thermal_image = np.reshape(thermal_json.temperature_map, (thermal_json.height, thermal_json.width))

# plot the result
plt.imshow(thermal_image, cmap="inferno")
plt.axis("off")
plt.show()
```

## Commands

### `flir -h`

Shows help on the flir application.

```commandline
> flir -h

Usage: flir [OPTIONS] COMMAND [ARGS]...

Options:
  --install-completion  Install completion for the current shell.
  --show-completion     Show completion for the current shell, to copy it or
                        customize the installation.
  -h, --help            Show this message and exit.

Commands:
  capture  Capture a thermal image from the FLIR camera.
  show     Show a captured image.
```

### `flir capture`

```commandline
> flir capture -h

Usage: flir capture [OPTIONS] OUTPUT

  Capture a thermal image from the FLIR camera.

Arguments:
  OUTPUT  [required]

Options:
  --simulate / --no-simulate  [default: no-simulate]
  -h, --help                  Show this message and exit.

```

### `flir show`

```commandline
> flir show -h

Usage: flir show [OPTIONS] INPUT

  Show a captured image.

Arguments:
  INPUT  [required]

Options:
  --legend / --no-legend  [default: no-legend]
  -h, --help              Show this message and exit.
```
