from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
from mpl_toolkits.axes_grid1 import make_axes_locatable

from nest.automation.sensors.flir import FlirThermalImage
from nest.automation.sensors.flir.rest import RestFlirConfig, RestFlirSensor
from nest.automation.sensors.flir.simulator import SimulatedFlirSensor
from nest.engineering.app import Application

app = Application(name="Flir", config_type=RestFlirConfig, config_path=Path("config.yml"))


def _create_flir_sensor(simulate: bool):
    if simulate:
        return app.di.create(SimulatedFlirSensor)
    else:
        return app.di.create(RestFlirSensor, config=app.config)


@app.cli.command()
def capture(output: Path, simulate: Optional[bool] = False):
    """Capture a thermal image from the FLIR camera."""
    flir = _create_flir_sensor(simulate)

    image = flir.capture()

    image.write_file(output)


@app.cli.command()
def show(input: Path, legend: Optional[bool] = False):
    """Show a captured image."""
    thermal_image = FlirThermalImage.read_file(input)

    im = plt.imshow(
        np.reshape(thermal_image.temperature_map, (thermal_image.height, thermal_image.width)),
        cmap="inferno",
    )
    plt.axis("off")

    if legend:
        ax = plt.gca()
        # create an axes on the right side of ax. The width of cax will be 5%
        # of ax and the padding between cax and ax will be fixed at 0.05 inch.
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.05)

        cb = plt.colorbar(im, cax=cax)
        ticks_loc = cb.ax.get_yticks().tolist()
        cb.ax.yaxis.set_major_locator(mticker.FixedLocator(ticks_loc))
        cb.ax.set_yticklabels([f"{x:.0f} °C" for x in ticks_loc])

    plt.show()


def main():
    app.cli()


if __name__ == "__main__":
    main()
