import io
import json
import re
import subprocess
from math import exp, log, sqrt
from pathlib import Path
from typing import Union

import numpy as np
from PIL import Image

from nest.automation.sensors.flir import FlirError
from nest.engineering.ddd import ValueObject


class FlirTemperatureConversionParameters(ValueObject):
    """Source https://github.com/gtatters/Thermimage/blob/master/R/raw2temp.R

    Note: PR1, PR2, PB, PF, and PO are specific to each camera and result from the calibration at factory of the
    camera's Raw data signal recording from a blackbody radiation source.
    """

    Emissivity: float  # Should be ~0.95 to 0.97 depending on source
    ObjectDistance: float  # (meters)
    ReflectedApparentTemperature: float  # (°C)
    AtmosphericTemperature: float  # For transmission loss (°C)
    InfraRedWindowTemperature: float  # (°C)
    InfraRedWindowTransmission: float  # Likely ~0.95-0.96. Should be empirically determined.
    RelativeHumidity: float  # (%)
    PlanckR1: float  # PlanckR1 calibration constant
    PlanckB: float  # PlanckB calibration constant
    PlanckF: float  # PlanckF calibration constant
    PlanckO: float  # PlanckO calibration constant
    PlanckR2: float  # PlanckR2 calibration constant
    AtmosphericTransmissionAlpha1: float
    AtmosphericTransmissionAlpha2: float
    AtmosphericTransmissionBeta1: float
    AtmosphericTransmissionBeta2: float
    AtmosphericTransmissionX: float


class FlirImageExtractor:
    """Source: https://github.com/Nervengift/read_thermal.py/blob/master/flir_image_extractor.py"""

    def __init__(self, exiftool_path: Union[str, Path] = "exiftool"):
        self.exiftool_path = exiftool_path

    def get_thermal_image(self, flir_img_filename: Union[str, Path]) -> np.ndarray:
        """
        Extracts the embedded thermal image data in °C.
        """
        # read image metadata needed for conversion of the raw sensor values
        try:
            meta_json = subprocess.check_output([self.exiftool_path, flir_img_filename, "-j"])
        except FileNotFoundError:
            raise FlirError(
                f"Failed to find exiftool at {self.exiftool_path}. "
                + "Please install exiftool with `conda install -c conda-forge exiftool`."
            )
        meta = json.loads(meta_json.decode())[0]
        conversion_factors = get_temperature_conversion_parameters(meta)

        # exifread can't extract the embedded thermal image, use exiftool instead
        thermal_img_bytes = subprocess.check_output([self.exiftool_path, "-RawThermalImage", "-b", flir_img_filename])
        thermal_img_stream = io.BytesIO(thermal_img_bytes)
        thermal_img = Image.open(thermal_img_stream)

        raw2tempfunc = np.vectorize(lambda x: flir_raw_to_temperature(x, conversion_factors))

        return raw2tempfunc(np.array(thermal_img))


def flir_raw_to_temperature(raw: int, conversion: FlirTemperatureConversionParameters):
    """
    Convert raw values from the FLIR sensor to temperatures in °C.

    ## Parameters
    raw: A/D 16-bit signal from FLIR file
    conversion: Camera parameters to convert raw signal into a temperature in Celsius.

    ## Source
    This calculation has been ported to Python from:
    https://github.com/gtatters/Thermimage/blob/master/R/raw2temp.R
    A detailed explanation of what is going on here can be found there

    Source for the conversion formulas: FLIR Toolkit IC2 Dig16 Developers Guide 1.01
    https://www.eevblog.com/forum/testgear/flir-e4-thermal-imaging-camera-teardown/?action=dlattach;attach=83950
    """
    c = conversion

    # Calibrated transmission through lens
    transmission_lens = 1 - c.InfraRedWindowTransmission
    reflection_lens = 0

    # Transmission through the air
    h2o = (c.RelativeHumidity / 100) * exp(
        1.5587
        + 0.06939 * c.AtmosphericTemperature
        - 0.00027816 * c.AtmosphericTemperature**2
        + 0.00000068455 * c.AtmosphericTemperature**3
    )
    tau1 = c.AtmosphericTransmissionX * exp(
        -sqrt(c.ObjectDistance / 2) * (c.AtmosphericTransmissionAlpha1 + c.AtmosphericTransmissionBeta1 * sqrt(h2o))
    ) + (1 - c.AtmosphericTransmissionX) * exp(
        -sqrt(c.ObjectDistance / 2) * (c.AtmosphericTransmissionAlpha2 + c.AtmosphericTransmissionBeta2 * sqrt(h2o))
    )
    tau2 = c.AtmosphericTransmissionX * exp(
        -sqrt(c.ObjectDistance / 2) * (c.AtmosphericTransmissionAlpha1 + c.AtmosphericTransmissionBeta1 * sqrt(h2o))
    ) + (1 - c.AtmosphericTransmissionX) * exp(
        -sqrt(c.ObjectDistance / 2) * (c.AtmosphericTransmissionAlpha2 + c.AtmosphericTransmissionBeta2 * sqrt(h2o))
    )

    # Radiance from the environment
    raw_refl1 = (
        c.PlanckR1 / (c.PlanckR2 * (exp(c.PlanckB / (c.ReflectedApparentTemperature + 273.15)) - c.PlanckF)) - c.PlanckO
    )
    raw_refl1_attn = (1 - c.Emissivity) / c.Emissivity * raw_refl1
    raw_atm1 = (
        c.PlanckR1 / (c.PlanckR2 * (exp(c.PlanckB / (c.AtmosphericTemperature + 273.15)) - c.PlanckF)) - c.PlanckO
    )
    raw_atm1_attn = (1 - tau1) / c.Emissivity / tau1 * raw_atm1
    raw_wind = (
        c.PlanckR1 / (c.PlanckR2 * (exp(c.PlanckB / (c.InfraRedWindowTemperature + 273.15)) - c.PlanckF)) - c.PlanckO
    )
    raw_wind_attn = transmission_lens / c.Emissivity / tau1 / c.InfraRedWindowTransmission * raw_wind
    raw_refl2 = (
        c.PlanckR1 / (c.PlanckR2 * (exp(c.PlanckB / (c.ReflectedApparentTemperature + 273.15)) - c.PlanckF)) - c.PlanckO
    )
    raw_refl2_attn = reflection_lens / c.Emissivity / tau1 / c.InfraRedWindowTransmission * raw_refl2
    raw_atm2 = (
        c.PlanckR1 / (c.PlanckR2 * (exp(c.PlanckB / (c.AtmosphericTemperature + 273.15)) - c.PlanckF)) - c.PlanckO
    )
    raw_atm2_attn = (1 - tau2) / c.Emissivity / tau1 / c.InfraRedWindowTransmission / tau2 * raw_atm2
    raw_obj = (
        raw / c.Emissivity / tau1 / c.InfraRedWindowTransmission / tau2
        - raw_atm1_attn
        - raw_atm2_attn
        - raw_wind_attn
        - raw_refl1_attn
        - raw_refl2_attn
    )

    # Temperature from radiance
    temp_celsius = c.PlanckB / log(c.PlanckR1 / (c.PlanckR2 * (raw_obj + c.PlanckO)) + c.PlanckF) - 273.15

    return temp_celsius


def extract_float(dirty_string: str) -> float:
    """
    Extract the float value of a string. Helpful for parsing the exiftool data which has units.
    """
    digits = re.findall(r"[-+]?\d*\.\d+|\d+", dirty_string)

    return float(digits[0])


def get_temperature_conversion_parameters(exif: dict) -> FlirTemperatureConversionParameters:
    return FlirTemperatureConversionParameters(
        Emissivity=exif["Emissivity"],
        ObjectDistance=extract_float(exif["SubjectDistance"]),
        ReflectedApparentTemperature=extract_float(exif["ReflectedApparentTemperature"]),
        AtmosphericTemperature=extract_float(exif["AtmosphericTemperature"]),
        InfraRedWindowTemperature=extract_float(exif["IRWindowTemperature"]),
        InfraRedWindowTransmission=exif["IRWindowTransmission"],
        RelativeHumidity=extract_float(exif["RelativeHumidity"]),
        PlanckR1=exif["PlanckR1"],
        PlanckB=exif["PlanckB"],
        PlanckF=exif["PlanckF"],
        PlanckO=exif["PlanckO"],
        PlanckR2=exif["PlanckR2"],
        AtmosphericTransmissionAlpha1=exif["AtmosphericTransAlpha1"],
        AtmosphericTransmissionAlpha2=exif["AtmosphericTransAlpha2"],
        AtmosphericTransmissionBeta1=exif["AtmosphericTransBeta1"],
        AtmosphericTransmissionBeta2=exif["AtmosphericTransBeta2"],
        AtmosphericTransmissionX=exif["AtmosphericTransX"],
    )
