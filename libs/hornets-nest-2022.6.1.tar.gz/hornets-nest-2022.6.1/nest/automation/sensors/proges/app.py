from asyncio.log import logger
from datetime import datetime
from typing import Optional
from xml.etree import ElementTree

from requests import Session

from nest.automation.sensors.proges import ProgesConfig, ProgesMeasurement, ProgesSensor
from nest.engineering.app import Application

app = Application(name="Proges")


@app.hooks.startup
def setup():
    app.di.register(ProgesSensor, tag=ProgesSensor, config=ProgesConfig())


@app.cli.command()
def track(ip: Optional[str] = "192.168.1.8"):
    """
    Start Temperature Sensor
    """
    session = Session()
    config = ProgesConfig(ip=ip)
    read_temperature(session=session, config=config)


def read_temperature(session: Session, config: ProgesConfig):
    try:
        while True:
            sessioninstance = session.get("http://" + config.ip + "/details.xml")
            root = ElementTree.fromstring(sessioninstance.text)
            stamp_str = root.find(config.xml_path + "DateTime").text
            for sensor in root.iter(config.xml_path + "owd_DS18B20"):
                temp_str = sensor.find(config.xml_path + "Temperature").text
                health_str = sensor.find(config.xml_path + "Health").text
                channel_str = sensor.find(config.xml_path + "Channel").text
                measure = ProgesMeasurement(
                    temp=float(temp_str),
                    health=int(health_str),
                    channel=int(channel_str),
                    stamp=datetime.strptime(stamp_str, "%Y-%m-%d %H:%M:%S"),
                )
                logger.info("Time: " + str(measure.stamp))
                logger.info("Channel: " + str(measure.channel))
                logger.info("Temperature: " + str(measure.temp))
                logger.info("Health: " + str(measure.health))
    except KeyboardInterrupt:
        logger.warn("interrupted")


def main():
    app.cli()


if __name__ == "__main__":
    main()
