import datetime
from abc import ABCMeta, abstractmethod

from nest.engineering.ddd import Service, ValueObject


class ProgesError(Exception):
    pass


class ProgesMeasurement(ValueObject):
    # TODO Define correct type
    channel: int
    temp: float
    health: int
    stamp: datetime.date


class ProgesConfig(ValueObject):
    xml_path = "{http://www.proges.com/schema/plugandtrack}"
    ip = "192.168.1.8"


class ProgesSensor(Service, metaclass=ABCMeta):
    @abstractmethod
    def startup(self):
        raise NotImplementedError

    @abstractmethod
    def shutdown(self):
        raise NotImplementedError

    @abstractmethod
    def measure(self) -> ProgesMeasurement:
        raise NotImplementedError
