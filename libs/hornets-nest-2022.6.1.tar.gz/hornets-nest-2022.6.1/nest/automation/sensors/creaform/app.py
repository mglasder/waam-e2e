import asyncio
from typing import List, Optional

from nest.automation.sensors.creaform import CreaformMeasurement, CreaformSensor
from nest.automation.sensors.creaform.dotnet import DotnetCreaformConfig, DotnetCreaformSensor
from nest.engineering.app import Application
from nest.engineering.utils.logger import LoggerMixin


class CreaformApp(LoggerMixin):
    _continue: bool
    creaform: DotnetCreaformSensor

    def __init__(self, configuration: DotnetCreaformConfig) -> None:
        self._continue = False
        self.creaform = DotnetCreaformSensor(config=configuration)
        self.creaform.handlers.append(self.handle_pose_stamped)

    def handle_pose_stamped(self, tracked_pose: CreaformMeasurement):
        self.logger.info(f"Received {tracked_pose}")

    def run(self):
        asyncio.run(self._async_main())

    def stop(self):
        self.logger.warning("Stopping the application...")
        self._stop = True

    async def _async_main(self):
        self.logger.info(f'{"Starting asyncio main"}')

        self._install_signal_handlers()

        await self.creaform.startup()

        self.logger.info("All module started")

        self._continue = True
        while self._continue:
            await asyncio.sleep(1)

        await self.creaform.shutdown()

    def _install_signal_handlers(self):
        loop = asyncio.get_event_loop()
        import signal

        signals = [
            signal.SIGINT,
            signal.SIGTERM,
        ]
        try:
            for sig in signals:
                loop.add_signal_handler(sig, self.stop)
        except NotImplementedError:
            self.logger.warning(
                "Skipped adding signal handler because current platform does not Support it. "
                "Application will not react to POSIX signals."
            )


app = Application(name="Creaform")


@app.hooks.startup
def setup():
    app.di.register(DotnetCreaformSensor, tag=CreaformSensor, config=DotnetCreaformConfig())


@app.cli.command()
def track(base: Optional[str] = "kuka_positioning_targets.txt", ee: Optional[List[str]] = ["KukaGripper.txt"]):
    """
    Start Tracking
    """
    config = DotnetCreaformConfig(reference_targets_filename=base, model_targets_filenames=ee)
    MyCreaformApp = CreaformApp(configuration=config)
    MyCreaformApp.run()


def main():
    app.cli()


if __name__ == "__main__":
    main()
