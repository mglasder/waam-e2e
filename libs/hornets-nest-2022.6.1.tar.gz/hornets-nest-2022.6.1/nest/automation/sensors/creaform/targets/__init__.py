from nest.engineering.utils import path_from_package

targets_path = str(path_from_package(__package__))
