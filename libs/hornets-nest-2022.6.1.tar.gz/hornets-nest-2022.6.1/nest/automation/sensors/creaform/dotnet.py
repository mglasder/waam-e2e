import asyncio
import sys
from asyncio import AbstractEventLoop
from queue import Queue
from typing import Awaitable, Callable, List, Optional

from pydantic import BaseModel

from nest.automation.sensors.creaform import CreaformError, CreaformMeasurement, CreaformSensor
from nest.automation.sensors.creaform.dlls import creaform_dotnet_dlls
from nest.automation.sensors.creaform.targets import targets_path


class DotnetCreaformConfig(BaseModel):
    reference_targets_filename: str = ""
    model_targets_filenames: List[str] = []
    dotnet_dlls: List[str] = creaform_dotnet_dlls


class DotnetCreaformSensor(CreaformSensor):
    def __init__(self, config: DotnetCreaformConfig):
        self._config = config

        self.queue = Queue()
        self.client = self._create_dotnet_client()

        self._continue = False
        self._future: Optional[Awaitable] = None

        self.handlers: List[Callable[[CreaformMeasurement], None]] = []

        self.event_loop: Optional[AbstractEventLoop] = None

    def _create_dotnet_client(self):
        try:
            sys.path.extend(self._config.dotnet_dlls)

            import clr

            clr.AddReference("UrcCreaformClient")

            from System import Action
            from UrcCreaformClient import CreaformClient as CreaformClientNet
            from UrcCreaformClient import TrackedPose as TrackedPoseNet

            return CreaformClientNet(
                on_tracking_data_ready=Action[TrackedPoseNet](self.queue.put),
            )
        except Exception as e:
            raise CreaformError("Could not load .net library") from e

    async def startup(self):
        self.logger.info("Startup...")

        self._continue = True
        self._future = asyncio.get_running_loop().run_in_executor(None, self._thread)

        self.client.Connect()

        reference_targets_filepath = targets_path + "\\" + self._config.reference_targets_filename
        self.client.LoadPositioning(str(reference_targets_filepath))

        for model_target in self._config.model_targets_filenames:
            model_target_filepath = targets_path + "\\" + model_target
            self.client.LoadModel(str(model_target_filepath))

        self.client.StartTracking()

    async def shutdown(self):
        self._continue = False
        if self._future:
            await asyncio.gather(self._future)

        self.client.StopTracking()

    async def measure(self):
        self.event_loop = asyncio.get_running_loop()
        self.logger.info("Started async thread")
        while self._continue:
            dotnet_pose = self.queue.get()
            pose = CreaformMeasurement.from_dotnet(dotnet_pose)
            for handler in self.handlers:
                handler(pose)

            self.queue.task_done()

    def _thread(self):
        self.logger.info("Started thread")
        asyncio.run(self.measure())
