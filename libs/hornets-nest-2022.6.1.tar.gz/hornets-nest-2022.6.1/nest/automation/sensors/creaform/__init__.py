from abc import ABCMeta, abstractmethod
from typing import List

from nest.engineering.ddd import Service, ValueObject


class CreaformError(Exception):
    pass


class CreaformMeasurement(ValueObject):
    index: int
    name: str
    timestamp: int
    pose_matrix: List[float]

    @classmethod
    def from_dotnet(cls, objnet):
        return cls(
            index=objnet.Index,
            name=objnet.Name,
            timestamp=objnet.Timestamp,
            pose_matrix=list(objnet.PoseMatrix),
        )


class CreaformSensor(Service, metaclass=ABCMeta):
    @abstractmethod
    def startup(self):
        raise NotImplementedError

    @abstractmethod
    def shutdown(self):
        raise NotImplementedError

    @abstractmethod
    def measure(self) -> CreaformMeasurement:
        raise NotImplementedError
