from typing import List

import compas_rrc as rrc

import nest.automation.robots.abb.compas_rrc_e001_instructions as rrc_e001
from compas.geometry import Frame, Point, Vector
from nest.automation.robots.abb import AbbRobot
from nest.engineering.ddd import Service, ValueObject
from nest.engineering.geometry import Point3, Vector3


class CompasAbbRosClient(Service):
    def __init__(self):
        self.ros = rrc.RosClient()

        # TODO Move this to startup hook for Service
        self.ros.run()


# TODO Refactor to use Config class
class CompasAbbRobotConfig(ValueObject):
    name: str

    # TODO Do we need this?
    speed_min = 100
    speed_medium = 200
    speed_max = 500


# TODO Find a better type than Service
class CompasAbbRobot(AbbRobot):
    def __init__(self, config: CompasAbbRobotConfig, ros_client: CompasAbbRosClient):
        self._config = config
        self._client = rrc.AbbClient(ros_client.ros, self._config.name)
        self._offset = Vector3.xyz(x=0, y=0, z=0)

    def set_tool(self, tool: str):
        self._client.send(rrc.SetTool(tool))

    def set_work_object(self, work_object: str):
        self._client.send(rrc.SetWorkObject(work_object))

    def set_offset(self, offset: Vector3):
        self._offset = offset

    def move_joints(self, joint_angles: List[float]):
        self._client.send_and_wait(
            rrc.MoveToJoints(
                joint_angles,
                [],
                self._config.speed_medium,
                rrc.Zone.FINE,
            )
        )

    def move_to_frame(self, point: Point3, axis_x: Vector3, axis_y: Vector3):
        self._client.send_and_wait(
            rrc.MoveToFrame(
                self._frame_from_point_and_axis(point, axis_x, axis_y),
                self._config.speed_medium,
                rrc.Zone.Z10,
                rrc.Motion.LINEAR,
            )
        )

    def job_start(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        self._client.send(
            rrc_e001.MoveToArcStart_Job(
                self._frame_from_point_and_axis(point, axis_x, axis_y),
                job_speed,
                rrc.Zone.FINE,
                job_number,
                job_speed,
            )
        )

    def job_continue(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        self._client.send(
            rrc_e001.MoveToArc_Job(
                self._frame_from_point_and_axis(point, axis_x, axis_y),
                job_speed,
                rrc.Zone.Z0,
                job_number,
                job_speed,
            )
        )

    def job_end(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        self._client.send(
            rrc_e001.MoveToArcEnd_Job(
                self._frame_from_point_and_axis(point, axis_x, axis_y),
                job_speed,
                rrc.Zone.FINE,
                job_number,
                job_speed,
            )
        )

    def _frame_from_point_and_axis(self, point: Point3, axis_x: Vector3, axis_y: Vector3):
        point_with_offset = point + self._offset
        return Frame(
            Point(point_with_offset.x, point_with_offset.y, point_with_offset.z),
            Vector(axis_x.x, axis_x.y, axis_x.z),
            Vector(axis_y.x, axis_y.y, axis_y.z),
        )
