from abc import abstractmethod
from typing import List

from nest.engineering.ddd import Service
from nest.engineering.geometry import Point3, Vector3


class AbbRobot(Service):
    @abstractmethod
    def set_tool(self, tool: str):
        raise NotImplementedError

    @abstractmethod
    def set_work_object(self, work_object: str):
        raise NotImplementedError

    @abstractmethod
    def set_offset(self, offset: Vector3):
        raise NotImplementedError

    @abstractmethod
    def move_joints(self, joint_angles: List[float]):
        raise NotImplementedError

    @abstractmethod
    def move_to_frame(self, point: Point3, axis_x: Vector3, axis_y: Vector3):
        raise NotImplementedError

    @abstractmethod
    def job_start(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        raise NotImplementedError

    @abstractmethod
    def job_continue(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        raise NotImplementedError

    @abstractmethod
    def job_end(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        raise NotImplementedError
