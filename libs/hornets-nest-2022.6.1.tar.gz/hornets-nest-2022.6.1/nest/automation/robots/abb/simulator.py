import time
from typing import List

from nest.automation.robots.abb import AbbRobot
from nest.engineering.geometry import Point3, Vector3


class SimulatedAbbRobot(AbbRobot):
    def __init__(self, name: str):
        self._name = name
        self._timeout = 0.1

    def set_tool(self, tool: str):
        self.logger.info(f"{self._name} set_tool {tool}")
        time.sleep(self._timeout)

    def set_work_object(self, work_object: str):
        self.logger.info(f"{self._name} set_work_object {work_object}")
        time.sleep(self._timeout)

    def set_offset(self, offset: Vector3):
        self.logger.info(f"{self._name} set_offset {offset}")

    def move_joints(self, joint_angles: List[float]):
        self.logger.info(f"{self._name} move_joints {joint_angles}")
        time.sleep(self._timeout)

    def move_to_frame(self, point: Point3, axis_x: Vector3, axis_y: Vector3):
        self.logger.info(f"{self._name} move_to_frame {point}")
        time.sleep(self._timeout)

    def job_start(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        self.logger.info(f"{self._name} job_start {point}")
        time.sleep(self._timeout)

    def job_continue(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        self.logger.info(f"{self._name} job_continue {point}")
        time.sleep(self._timeout)

    def job_end(self, point: Point3, axis_x: Vector3, axis_y: Vector3, job_number: int, job_speed: float):
        self.logger.info(f"{self._name} job_end {point}")
        time.sleep(self._timeout)
