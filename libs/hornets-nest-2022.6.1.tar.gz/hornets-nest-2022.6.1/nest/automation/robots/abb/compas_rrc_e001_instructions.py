# flake8: noqa
from compas_fab.backends.ros.messages import ROSmsg
from compas_fab.robots import Configuration
from compas_rrc.common import ExecutionLevel, FeedbackLevel
from compas_rrc.motion import Motion, MoveGeneric

INSTRUCTION_PREFIX = "r_E001_"

__all__ = [
    "MoveToArcStart_Job",
    "MoveToArc_Job",
    "MoveToArcEnd_Job",
    "MoveToArcStart_Prog",
    "MoveToArc_Prog",
    "MoveToArcEnd_Prog",
]


class MoveToArcStart_Job(MoveGeneric):
    """Move to arc start is a call that moves the robot in the cartisian space to the arc start position and will start the weld.

    RAPID Instruction: ``r_E001_MoveToArcStart_Job``

    Attributes:

        frame (:class:`compas.geometry.Frame`):
            Target frame.

        ext_axes (:class:`compas_rrc.common.ExternalAxes` or :obj:`list` of :obj:`float`):
            External axes positions.

        speed (:obj:`int`):
            Integer specifying TCP translational speed in mm/s. Min=``0.01``.

        zone (:class:`Zone`):
            Zone data. Predefined in the robot controller,
            only Zone ``fine`` will do a stop point all others are fly by points

        weldjop (:obj: `int`):
            Control weld job

        weldspeed (:obj: `int`):
            Control weld speed [mm/s]

        motion_type (:class:`Motion`):
            Motion type. Defaults to Linear.

        feedback_level (:obj:`int`):
            Integer specifying requested feedback level. Default=``0`` (i.e. ``NONE``).
            Feedback level is instruction-specific but the value ``1`` always represents
            completion of the instruction.

    """

    def __init__(
        self, frame, speed, zone, weldjop, weldspeed, motion_type=Motion.LINEAR, feedback_level=FeedbackLevel.NONE
    ):
        super(MoveToArcStart_Job, self).__init__(frame, [], speed, zone, feedback_level)
        self.instruction = INSTRUCTION_PREFIX + "MoveToArcStart_Job"
        self.exec_level = ExecutionLevel.ROBOT

        move_type = "J" if motion_type == Motion.JOINT else "L"
        self.string_values = [move_type]
        self.float_values.extend([weldjop, weldspeed])


class MoveToArc_Job(MoveGeneric):
    """Move to arc start is a call that moves the robot in the cartisian space to the arc start position and will start the weld.

    RAPID Instruction: ``r_E001_MoveToArc_Job``

    Attributes:

        frame (:class:`compas.geometry.Frame`):
            Target frame.

        ext_axes (:class:`compas_rrc.common.ExternalAxes` or :obj:`list` of :obj:`float`):
            External axes positions.

        speed (:obj:`int`):
            Integer specifying TCP translational speed in mm/s. Min=``0.01``.

        zone (:class:`Zone`):
            Zone data. Predefined in the robot controller,
            only Zone ``fine`` will do a stop point all others are fly by points

        weldjop (:obj: `int`):
            Control weld job

        weldspeed (:obj: `int`):
            Control weld speed [mm/s]

        motion_type (:class:`Motion`):
            Motion type. Defaults to Linear.

        feedback_level (:obj:`int`):
            Integer specifying requested feedback level. Default=``0`` (i.e. ``NONE``).
            Feedback level is instruction-specific but the value ``1`` always represents
            completion of the instruction.

    """

    def __init__(
        self, frame, speed, zone, weldjop, weldspeed, motion_type=Motion.LINEAR, feedback_level=FeedbackLevel.NONE
    ):
        super(MoveToArc_Job, self).__init__(frame, [], speed, zone, feedback_level)
        self.instruction = INSTRUCTION_PREFIX + "MoveToArc_Job"
        self.exec_level = ExecutionLevel.ROBOT

        move_type = "J" if motion_type == Motion.JOINT else "L"
        self.string_values = [move_type]
        self.float_values.extend([weldjop, weldspeed])


class MoveToArcEnd_Job(MoveGeneric):
    """Move to arc start is a call that moves the robot in the cartisian space to the arc start position and will start the weld.

    RAPID Instruction: ``r_E001_MoveToArcEnd_Job``

    Attributes:

        frame (:class:`compas.geometry.Frame`):
            Target frame.

        ext_axes (:class:`compas_rrc.common.ExternalAxes` or :obj:`list` of :obj:`float`):
            External axes positions.

        speed (:obj:`int`):
            Integer specifying TCP translational speed in mm/s. Min=``0.01``.

        zone (:class:`Zone`):
            Zone data. Predefined in the robot controller,
            only Zone ``fine`` will do a stop point all others are fly by points

        weldjop (:obj: `int`):
            Control weld job

        weldspeed (:obj: `int`):
            Control weld speed [mm/s]

        motion_type (:class:`Motion`):
            Motion type. Defaults to Linear.

        feedback_level (:obj:`int`):
            Integer specifying requested feedback level. Default=``0`` (i.e. ``NONE``).
            Feedback level is instruction-specific but the value ``1`` always represents
            completion of the instruction.

    """

    def __init__(
        self, frame, speed, zone, weldjop, weldspeed, motion_type=Motion.LINEAR, feedback_level=FeedbackLevel.NONE
    ):
        super(MoveToArcEnd_Job, self).__init__(frame, [], speed, zone, feedback_level)
        self.instruction = INSTRUCTION_PREFIX + "MoveToArcEnd_Job"
        self.exec_level = ExecutionLevel.ROBOT

        move_type = "J" if motion_type == Motion.JOINT else "L"
        self.string_values = [move_type]
        self.float_values.extend([weldjop, weldspeed])


class MoveToArcStart_Prog(MoveGeneric):
    """Move to arc start is a call that moves the robot in the cartisian space to the arc start position and will start the weld.

    RAPID Instruction: ``r_E001_MoveToArcStart_Prog``

    Attributes:

        frame (:class:`compas.geometry.Frame`):
            Target frame.

        ext_axes (:class:`compas_rrc.common.ExternalAxes` or :obj:`list` of :obj:`float`):
            External axes positions.

        speed (:obj:`int`):
            Integer specifying TCP translational speed in mm/s. Min=``0.01``.

        zone (:class:`Zone`):
            Zone data. Predefined in the robot controller,
            only Zone ``fine`` will do a stop point all others are fly by points

        motion_type (:class:`Motion`):
            Motion type. Defaults to Linear.

        feedback_level (:obj:`int`):
            Integer specifying requested feedback level. Default=``0`` (i.e. ``NONE``).
            Feedback level is instruction-specific but the value ``1`` always represents
            completion of the instruction.

    """

    def __init__(self, frame, speed, zone, motion_type=Motion.LINEAR, feedback_level=FeedbackLevel.NONE):
        super(MoveToArcStart_Prog, self).__init__(frame, [], speed, zone, feedback_level)
        self.instruction = INSTRUCTION_PREFIX + "MoveToArcStart_Prog"
        self.exec_level = ExecutionLevel.ROBOT

        move_type = "J" if motion_type == Motion.JOINT else "L"
        self.string_values = [move_type]
        self.float_values.extend([])


class MoveToArc_Prog(MoveGeneric):
    """Move to arc start is a call that moves the robot in the cartisian space to the arc start position and will start the weld.

    RAPID Instruction: ``r_E001_MoveToArc_Prog``

    Attributes:

        frame (:class:`compas.geometry.Frame`):
            Target frame.

        ext_axes (:class:`compas_rrc.common.ExternalAxes` or :obj:`list` of :obj:`float`):
            External axes positions.

        speed (:obj:`int`):
            Integer specifying TCP translational speed in mm/s. Min=``0.01``.

        zone (:class:`Zone`):
            Zone data. Predefined in the robot controller,
            only Zone ``fine`` will do a stop point all others are fly by points

        motion_type (:class:`Motion`):
            Motion type. Defaults to Linear.

        feedback_level (:obj:`int`):
            Integer specifying requested feedback level. Default=``0`` (i.e. ``NONE``).
            Feedback level is instruction-specific but the value ``1`` always represents
            completion of the instruction.

    """

    def __init__(self, frame, speed, zone, motion_type=Motion.LINEAR, feedback_level=FeedbackLevel.NONE):
        super(MoveToArc_Prog, self).__init__(frame, [], speed, zone, feedback_level)
        self.instruction = INSTRUCTION_PREFIX + "MoveToArc_Prog"
        self.exec_level = ExecutionLevel.ROBOT

        move_type = "J" if motion_type == Motion.JOINT else "L"
        self.string_values = [move_type]
        self.float_values.extend([])


class MoveToArcEnd_Prog(MoveGeneric):
    """Move to arc start is a call that moves the robot in the cartisian space to the arc start position and will start the weld.

    RAPID Instruction: ``r_E001_MoveToArcEnd_Prog``

    Attributes:

        frame (:class:`compas.geometry.Frame`):
            Target frame.

        ext_axes (:class:`compas_rrc.common.ExternalAxes` or :obj:`list` of :obj:`float`):
            External axes positions.

        speed (:obj:`int`):
            Integer specifying TCP translational speed in mm/s. Min=``0.01``.

        zone (:class:`Zone`):
            Zone data. Predefined in the robot controller,
            only Zone ``fine`` will do a stop point all others are fly by points

        motion_type (:class:`Motion`):
            Motion type. Defaults to Linear.

        feedback_level (:obj:`int`):
            Integer specifying requested feedback level. Default=``0`` (i.e. ``NONE``).
            Feedback level is instruction-specific but the value ``1`` always represents
            completion of the instruction.

    """

    def __init__(self, frame, speed, zone, motion_type=Motion.LINEAR, feedback_level=FeedbackLevel.NONE):
        super(MoveToArcEnd_Prog, self).__init__(frame, [], speed, zone, feedback_level)
        self.instruction = INSTRUCTION_PREFIX + "MoveToArcEnd_Prog"
        self.exec_level = ExecutionLevel.ROBOT

        move_type = "J" if motion_type == Motion.JOINT else "L"
        self.string_values = [move_type]
        self.float_values.extend([])
