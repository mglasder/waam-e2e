import asyncio
from pathlib import Path
from typing import Generic, Optional, Type, TypeVar, Union

from typer import Option, Typer

from nest.engineering.app.di import DependencyInjection
from nest.engineering.app.hook import Hook
from nest.engineering.app.scheduler import Scheduler
from nest.engineering.config import BaseConfig
from nest.engineering.utils.logger import LoggerMixin


class ApplicationHooks(LoggerMixin):
    def __init__(self):
        self.startup = Hook("startup")
        self.shutdown = Hook("shutdown")
        self.heartbeat = Hook("heartbeat")


AppConfigType = TypeVar("AppConfigType", bound=BaseConfig)


class Application(Generic[AppConfigType], LoggerMixin):
    def __init__(
        self,
        name,
        *,
        config: Optional[AppConfigType] = None,
        config_type: Type[AppConfigType] = BaseConfig,
        config_path: Union[Path, str] = Path("config.yml"),
    ):
        self.name = name
        self.cli = Typer(
            name=name,
            context_settings={"help_option_names": ["-h", "--help"]},
            callback=self._cli_startup,
            result_callback=self._cli_shutdown,
        )
        self._di = DependencyInjection()
        self.di.register(self, tag=Application)
        self.di.register(Scheduler)

        self._hooks = ApplicationHooks()

        self.config = config
        self.config_path = Path(config_path)
        if not self.config and self.config_path.exists():
            self.config = config_type.read_file(self.config_path)

    @property
    def di(self):
        return self._di

    @property
    def hooks(self):
        return self._hooks

    @property
    def scheduler(self):
        return self.di.get(Scheduler)

    def startup(self):
        self.logger.info("Startup")
        self.hooks.startup.trigger()

    def shutdown(self):
        self.logger.info("Shutdown")
        self.hooks.shutdown.trigger()
        self.di.stop()

    def _cli_startup(
        self,
        verbose: int = Option(
            0,
            "--verbose",
            "-v",
            count=True,
        ),
    ):
        # TODO Configure logger
        self.logger.warning(f"TODO set logging level to {verbose}")

        self.startup()

    def _cli_shutdown(self, *args, **kwargs):
        self.shutdown()

    def __call__(self, *args, **kwargs):
        async def _cli_main_loop():
            self.cli(*args, **kwargs)

        asyncio.run(_cli_main_loop(), debug=True)

    def extend(self, app: "Application"):
        # TODO Find config from main app?
        # TODO Merge DependencyInjection?

        self.cli.add_typer(app.cli, name=app.name)
