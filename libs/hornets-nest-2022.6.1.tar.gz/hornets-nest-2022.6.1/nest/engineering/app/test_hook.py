import pytest
from pytest_mock import MockerFixture

from nest.engineering.app import Hook


@pytest.fixture
def hook():
    return Hook("hook")


def test_hook_code(mocker: MockerFixture, hook):
    mock = mocker.Mock()

    hook.register(mock)

    hook.trigger()

    mock.assert_called_once_with()


def test_hook_decorator(mocker: MockerFixture, hook):
    mock = mocker.Mock()

    @hook
    def something():
        mock()

    hook.trigger()

    mock.assert_called_once_with()
