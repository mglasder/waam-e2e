from nest.engineering.utils.logger import LoggerMixin


class Hook(LoggerMixin):
    def __init__(self, name=None):
        self._name = name
        self._hooks = []

    def __call__(self, func):
        return self.register(func)

    def register(self, func):
        self.logger.debug(f"Hooked {func} as {self._name}")
        self._hooks.append(func)
        return func

    def trigger(self, *args, **kwargs):
        self.logger.debug(f"Triggering {self._name}...")
        for h in self._hooks:
            # TODO Check if awaitable
            h(*args, **kwargs)
