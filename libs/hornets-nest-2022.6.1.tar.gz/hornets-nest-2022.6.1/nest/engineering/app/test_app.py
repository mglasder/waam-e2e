from assertpy import assert_that

from nest.engineering.app import Application
from nest.engineering.config import BaseConfig


def test_app_cli(cli_runner):
    app = Application("test-cli")

    @app.cli.command("something")
    def something():
        pass

    result = cli_runner(app, ["something"])
    assert_that(result).is_cli_success()


class SomeConfig(BaseConfig):
    value = 4


def test_app_cli_config(cli_runner, tmp_path):
    config_path = tmp_path / "config.yml"
    SomeConfig(value=5).write_file(config_path)

    app = Application(
        "test-cli",
        config_type=SomeConfig,
        config_path=config_path,
    )

    assert_that(app.config.value).is_equal_to(5)


def test_app_extend(cli_runner):
    app = Application("cli1")

    @app.cli.command("something")
    def something():
        pass

    app_ext = Application("cli2")

    @app_ext.cli.command("something")
    def something_else():
        pass

    app.extend(app_ext)

    result = cli_runner(app, ["something"])
    assert_that(result).is_cli_success()

    result = cli_runner(app, ["cli2", "something"])
    assert_that(result).is_cli_success()


def test_app_asyncio(cli_runner):

    from nest.engineering.app.sample_app import app

    result = cli_runner(app, ["sl"])
    assert_that(result).is_cli_success()
    assert_that(result.stdout).contains("start", "done", "something")
