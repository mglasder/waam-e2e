import asyncio
import threading
from asyncio import AbstractEventLoop, Future
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Coroutine, List, Optional

from nest.engineering.ddd import Service
from nest.engineering.utils.logger import LoggerMixin


class AsyncThread(LoggerMixin):
    def __init__(
        self,
        handler: Coroutine,
        handle_success: Optional[Callable] = None,
        handle_exception: Optional[Callable] = None,
        loop: AbstractEventLoop = None,
        executor: ThreadPoolExecutor = None,
    ):
        self.handler = handler
        self.handle_success = handle_success
        self.handle_exception = handle_exception
        self.loop = loop if loop else asyncio.get_running_loop()

        # TODO Change to debug
        self.future = self.loop.run_in_executor(executor, self.thread_callback)
        self.future.add_done_callback(self.done_callback)

    def thread_callback(self):
        self.logger.debug(f"Handling thread_callback from {threading.current_thread().name}")
        return asyncio.run(self.handler)

    def done_callback(self, future: Future):
        self.logger.debug(f"Handling done_callback from {threading.current_thread().name}")
        try:
            result = future.result()
            if self.handle_success:
                self.handle_success(result)
        except Exception as ex:  # noqa
            if self.handle_exception:
                self.handle_exception(ex)
            else:
                self.logger.exception(f"Failed while executing {self.handler}")


class Scheduler(Service):
    def __init__(self):
        self._executors: List[ThreadPoolExecutor] = []

    def on_startup(self):
        self.logger.info("on_startup...")
        self._install_signal_handlers()

    def on_shutdown(self):
        self.logger.info("on_shutdown...")
        # TODO Scheduler shutdown

    def _install_signal_handlers(self):
        # TODO Graceful exit https://stackoverflow.com/questions/45987985/asyncio-loops-add-signal-handler-in-windows
        loop = asyncio.get_event_loop()
        import signal

        signals = [
            signal.SIGINT,
            signal.SIGTERM,
        ]
        try:
            for sig in signals:
                loop.add_signal_handler(sig, self.stop)
        except NotImplementedError:
            self.logger.warning(
                "Skipped adding signal handler because current platform does not Support it. "
                "Application will not react to POSIX signals."
            )

    def run(self, coroutine: Coroutine):
        AsyncThread(coroutine)
