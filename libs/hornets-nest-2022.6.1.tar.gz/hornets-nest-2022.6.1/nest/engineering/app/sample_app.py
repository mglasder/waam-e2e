import asyncio
import time

import typer

from nest.engineering.app import Application
from nest.engineering.utils.logger import get_logger

app = Application("cli-asyncio")

logger = get_logger("app_something")


async def something(delay: int):
    await asyncio.sleep(delay)
    typer.echo("something")


@app.cli.command()
def sl():
    delay = 1
    typer.echo("start")
    coro = something(delay)
    app.scheduler.run(coro)
    time.sleep(2)
    typer.echo("done")


if __name__ == "__main__":
    app()
