# Application

> TODO

## Configuration

> TODO

## Lifecycle with Hooks

> TODO

## Dependency Injection

[Dependency Injection](https://en.wikipedia.org/wiki/Dependency_injection) is a technique to register a list of services
and then inject them at run time into the other services that depends on it. After being instantiated,
the `DependencyInjection` service allows to inject the registered service using the `@di.inject` decorator.

The following code provides a simple example of how to use the `DependencyInjection`:

```python
from nest.engineering.app.di import DependencyInjection


class SomeService:
    def __init__(self, some_param: any):
        self.some_param = some_param


class SomeOtherService:
    def __init__(self, some_service: SomeService):
        self.some_service = some_service


di = DependencyInjection()

di.register(SomeService, some_param=1)
some_service = di.get(SomeService)

di.register(SomeOtherService)
some_other_service = di.get(SomeOtherService)
```

## CLI

> TODO

## API

> TODO
