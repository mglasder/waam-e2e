import pytest
from assertpy import assert_that

from nest.engineering.app.di import DependencyInjection, Tag


class SomeService:
    def __init__(self, some_param: any):
        self.some_param = some_param


class SomeChildService(SomeService):
    pass


class SomeOtherService:
    def __init__(self, some_service: SomeService):
        self.some_service = some_service


class SpecialService:
    counter = 0

    def __init__(self):
        SpecialService.counter += 1


@pytest.fixture
def di():
    di = DependencyInjection()
    yield di


def test_dependency_simple_injection_register_and_retrieve(di):
    di.register(SomeService, some_param=1)

    injected_service = di.get(SomeService)
    assert_that(injected_service).is_instance_of(SomeService)

    assert_that(injected_service.some_param).is_equal_to(1)


def test_dependency_simple_injection_is_not_registered(di):
    with pytest.raises(ValueError):
        injected_service = di.get(SomeService)
        assert_that(injected_service).is_not_none()


def test_dependency_simple_injection_is_already_registered(di):
    di.register(SomeService, some_param=1)
    with pytest.raises(ValueError):
        di.register(SomeService, some_param=1)


def test_dependency_double_injection(di):
    di.register(SomeService, some_param=1)

    di.register(SomeOtherService)
    some_other_service = di.get(SomeOtherService)

    assert_that(some_other_service.some_service).is_equal_to(di.get(SomeService))


def test_dependency_double_injection_by_overriding_injected_service(di):
    di.register(SomeService, some_param=1)

    other_service = SomeService(some_param=5)
    di.register(SomeOtherService, some_service=other_service)
    some_other_service = di.get(SomeOtherService)

    assert_that(some_other_service.some_service).is_equal_to(other_service)
    assert_that(some_other_service.some_service).is_not_equal_to(di.get(SomeService))


def test_dependency_with_tags(di):
    tag1 = Tag(SomeService, "service1")
    di.register(tag1, some_param=1)

    tag2 = Tag(SomeService, "service2")
    di.register(SomeChildService, tag=tag2, some_param=2)

    di.register(SomeOtherService, some_service=tag2)

    some_other_service = di.get(SomeOtherService)
    service1 = di.get(tag1)
    service2 = di.get(tag2)

    assert_that(service1.some_param).is_equal_to(1)
    assert_that(service2).is_instance_of(SomeChildService)
    assert_that(service2.some_param).is_equal_to(2)
    assert_that(some_other_service.some_service).is_equal_to(service2)
