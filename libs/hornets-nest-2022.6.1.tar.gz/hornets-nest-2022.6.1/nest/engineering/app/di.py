import functools
import inspect
from types import FunctionType
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, TypeVar, Union, get_type_hints

from nest.engineering.ddd import Service
from nest.engineering.utils.typing import get_class_path

Injectable = TypeVar("Injectable")


class Tag:
    def __init__(self, cls: Type[Injectable], name: Optional[str] = None):
        assert isinstance(cls, type)
        assert isinstance(name, (str, type(None)))

        self.cls = cls
        self.name = name

    @property
    def path(self):
        if not self.name:
            return f"{get_class_path(self.cls)}"

        return f"{get_class_path(self.cls)}#{self.name}"

    def __str__(self):
        return self.path

    def __repr__(self):
        return self.__str__()

    @staticmethod
    def from_obj(obj: Any):
        if not obj:
            raise ValueError("Could not resolve tag")

        if isinstance(obj, Tag):
            return obj

        if isinstance(obj, type):
            return Tag(obj)

        return Tag(type(obj))


class DependencyInjection(Service):
    def __init__(self):
        self._factories: Dict[str, Tuple[Callable, Tuple, Dict]] = {}
        self._instances: Dict[str, Any] = {}
        self._services: List[Service] = []

    def reset(self):
        self._factories = {}
        self._instances = {}
        self._services = []
        self.logger.debug("Reset")

    def stop(self):
        for service in reversed(self._services):
            self.logger.info(f"Calling on_shutdown for {service}")
            self.call(service.on_shutdown)

        self.reset()

    def __contains__(self, item):
        path = get_class_path(item)
        return path in self._factories

    def register(
        self,
        obj: Any,
        tag: Optional[Union[Tag, Any]] = None,
        override=False,
        *args,
        **kwargs,
    ):
        tag = Tag.from_obj(tag if tag else obj)
        if isinstance(obj, Tag):
            self._register_factory(obj=tag.cls, tag=tag, override=override, args=args, kwargs=kwargs)
        elif isinstance(obj, (type, FunctionType)):
            self._register_factory(obj=obj, tag=tag, override=override, args=args, kwargs=kwargs)
        else:
            if kwargs:
                self.logger.warning("Usage of additional arguments is not possible")

            self._register_instance(obj=obj, tag=tag, override=override)

    def _register_factory(self, obj: Any, tag: Tag, override: bool, args: Tuple, kwargs: Dict):
        if not override and tag.path in self._factories:
            raise ValueError(f"Factory {tag} is already registered")

        self._factories[tag.path] = (obj, args, kwargs)
        self.logger.debug(f"Registered factory {tag}")

    def _register_instance(self, obj: Any, tag: Tag, override: bool):
        if not override and tag.path in self._instances:
            raise ValueError(f"Instance {tag} is already registered")

        self._instances[tag.path] = obj
        self.logger.debug(f"Registered instance {tag} of type {get_class_path(obj)}")

        if isinstance(obj, Service):
            self.logger.info(f"Calling on_startup for {obj}")
            self.call(obj.on_startup)
            self._services.append(obj)

    def get(self, obj: Union[Type[Injectable], Tag]) -> Injectable:
        tag = Tag.from_obj(obj)
        if tag.path not in self._factories:
            # TODO Should we try to simply create it?
            raise ValueError(f"Service {tag} has not been registered")

        # TODO Detect cyclic dependency
        if tag.path not in self._instances:
            func, args, kwargs = self._factories[tag.path]
            self._register_instance(
                obj=self.create(func, *args, **kwargs),
                tag=tag,
                override=False,
            )

        return self._instances[tag.path]

    def call(self, func: Callable[..., Injectable], *args, **kwargs) -> Injectable:
        return self.create(func, *args, **kwargs)

    # TODO Rename to inject
    def create(self, func: Callable[..., Injectable], *args, **kwargs) -> Injectable:
        signature = inspect.signature(func)
        type_hints = get_type_hints(func)
        if isinstance(func, type):
            signature = inspect.signature(func.__init__)
            type_hints = get_type_hints(func.__init__)

        # Skip all provided positional argument
        n = len(args)
        params = list(signature.parameters.values())

        for param in params[n:]:
            # If provided as a name argument -> skip
            if param.name in kwargs:
                tag = kwargs[param.name]
                if isinstance(tag, Tag):
                    kwargs[param.name] = self.get(tag)
                continue

            # If no type hint is provided -> skip
            if param.name not in type_hints:
                continue

            # Inject
            cls = type_hints[param.name]
            if cls in self:
                kwargs[param.name] = self.get(cls)

        # TODO Detect which parameters are not provided
        return func(*args, **kwargs)

    def __call__(self, func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return self.create(func, *args, **kwargs)

        return wrapper
