from nest.engineering.utils.pydantic import BaseSettings


class BaseConfig(BaseSettings):
    pass
