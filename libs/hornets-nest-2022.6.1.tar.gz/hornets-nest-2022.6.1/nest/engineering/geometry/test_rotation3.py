import numpy as np
import pytest
from assertpy import assert_that
from scipy.spatial.transform import Rotation as SciPyRotation3

from nest.engineering.geometry import Rotation3

rot = Rotation3.array([1, 0, 0, 0])

other_rotations = [
    [1, 0, 0, 0],
    [
        [1, 0, 0],
        [0, -1, 0],
        [0, 0, -1],
    ],
    SciPyRotation3.from_quat([1, 0, 0, 0]),
    [np.pi, 0, 0],
]


@pytest.mark.parametrize("other_rotation", other_rotations)
def test_rotation3(other_rotation):
    r1 = Rotation3.array(other_rotation)
    assert_that(r1.quaternion).is_close_to([1, 0, 0, 0], tolerance=1e-5)


@pytest.mark.parametrize("other_rotation", other_rotations)
def test_rot_mult(other_rotation):
    assert_that(Rotation3.identity() * other_rotation).is_close_to([1, 0, 0, 0], tolerance=1e-5)


@pytest.mark.skip("Debug for matrix multiplication")
def test_rot_mat_mult():
    assert_that(Rotation3.identity() @ [1, 2, 3]).is_close_to([1, 2, 3], tolerance=1e-5)
