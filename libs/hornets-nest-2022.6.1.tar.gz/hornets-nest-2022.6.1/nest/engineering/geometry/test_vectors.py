import numpy as np
import pytest
from assertpy import assert_that

from nest.engineering.geometry import Point3, Vector2, Vector3, VectorN

other_vectors = [
    Vector3.xyz(1, 2, 3),
    Point3.xyz(1, 2, 3),
    np.array([1, 2, 3]),
    [1, 2, 3],
]


def test_vector2():
    v2 = Vector2.xy(1, 2)
    assert_that(v2.x).is_equal_to(1)
    assert_that(v2.y).is_equal_to(2)


def test_vector3():
    v3 = Vector3.xyz(1, 2, 3)
    assert_that(v3.x).is_equal_to(1)
    assert_that(v3.y).is_equal_to(2)
    assert_that(v3.z).is_equal_to(3)


def test_vector_n():
    v = VectorN.array([1, 2, 3, 4])
    assert_that(v.rows).is_equal_to(1)
    assert_that(v.colums).is_equal_to(4)


def test_vector_list():
    v = Vector3.array(
        [
            [1, 2, 3],
            [4, 5, 6],
        ]
    )
    assert_that(v.rows).is_equal_to(2)
    assert_that(v.colums).is_equal_to(3)


@pytest.mark.parametrize("other_vector", other_vectors)
def test_vector_add(other_vector):
    assert_that(Vector3.xyz(1, 2, 3) + other_vector).is_equal_to([2, 4, 6])


@pytest.mark.parametrize("other_vector", other_vectors)
def test_vector_sub(other_vector):
    assert_that(Vector3.xyz(1, 2, 3) - other_vector).is_equal_to([0, 0, 0])


def test_vector_unary_neg():
    assert_that(-Vector3.xyz(1, 2, 3)).is_equal_to([-1, -2, -3])


def test_vector_mult():
    assert_that(Vector3.xyz(1, 2, 3) * 2).is_equal_to([2, 4, 6])


def test_vector_div():
    assert_that(Vector3.xyz(2, 4, 6) / 2).is_equal_to([1, 2, 3])


@pytest.mark.parametrize("other_vector", other_vectors)
def test_vec_mult(other_vector):
    assert_that(Vector3.xyz(1, 2, 3) * other_vector).is_equal_to([1, 4, 9])


@pytest.mark.parametrize("other_vector", other_vectors)
def test_mat_mult(other_vector):
    assert_that(Vector3.xyz(1, 2, 3).transpose() @ other_vector).is_equal_to(
        [
            [1, 2, 3],
            [2, 4, 6],
            [3, 6, 9],
        ]
    )


@pytest.mark.parametrize("other_vector", other_vectors)
def test_vec_div(other_vector):
    assert_that(Vector3.xyz(1, 2, 3) / other_vector).is_equal_to([1, 1, 1])


def test_vector_norm():
    assert_that(Vector3.xyz(1, 2, 3).norm()).is_equal_to(np.sqrt(14))


def test_vector_normalize():
    assert_that(Vector3.xyz(2, 0, 0).normalize()).is_equal_to([1, 0, 0])
