from assertpy import assert_that

from nest.engineering.geometry import Point3, Pose3, Rotation3


def test_pose3():
    pose = Pose3(
        position=Point3.xyz(1, 2, 3),
        rotation=Rotation3.identity(),
    )
    assert_that(pose.matrix).is_equal_to(
        [
            [1, 0, 0, 1],
            [0, 1, 0, 2],
            [0, 0, 1, 3],
            [0, 0, 0, 1],
        ]
    )
