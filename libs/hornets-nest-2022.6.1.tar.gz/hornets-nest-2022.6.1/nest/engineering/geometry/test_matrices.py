import numpy as np
import pytest
from assertpy import assert_that

from nest.engineering.geometry import Matrix


def test_matrix_inverse():
    mat = Matrix.array([[1, 2], [3, 4]])
    mat_inv = mat.inverse()
    id2 = mat @ mat_inv
    assert_that(id2).is_close_to(Matrix.identity(2), tolerance=1e5)


@pytest.mark.parametrize("size", [2, 3, 4, 5])
def test_matrix_inverse_identity(size):
    mat = Matrix.identity(size)
    assert_that(mat.inverse()).is_equal_to(np.eye(size))
