from assertpy import assert_that

from nest.engineering.ddd import ValueObject
from nest.engineering.geometry import Matrix, Point3, Pose3, Rotation3, Vector2, Vector3, VectorN


def test_serialization(tmp_path):
    file_path = tmp_path / "something.json"

    class SomeModel(ValueObject):
        v2 = Vector2.xy(1, 2)
        v3 = Vector3.xyz(1, 2, 3)
        v6 = VectorN.array([1, 2, 3, 4, 5, 6])
        m = Matrix.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        v3x3 = Vector3.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        rot = Rotation3.array([1, 0, 0, 0])
        pose = Pose3(
            position=Point3.array([1, 2, 3]),
            rotation=Rotation3.identity(),
        )

    sm = SomeModel()
    sm.write_file(file_path)

    sm2 = SomeModel.read_file(file_path)

    assert_that(sm).is_equal_to(sm2)
