from typing import Any

import numpy as np
from scipy.spatial.transform import Rotation as SciPyRotation3

from nest.engineering.ddd import ValueObject


class GeometryError(Exception):
    pass


class Matrix(ValueObject):
    __size__: int

    __root__: np.ndarray

    @property
    def shape(self):
        return self.__root__.shape

    @property
    def colums(self):
        _, columns = self.__root__.shape
        return columns

    @property
    def rows(self):
        rows, _ = self.__root__.shape
        return rows

    @property
    def ndarray(self):
        return self.__root__

    @classmethod
    def array(cls, array):
        if isinstance(array, cls):
            return array

        # TODO Ensure list of list is not flatten if second list has only 1 element
        ndarray = np.array(array)
        if len(ndarray.shape) == 1:
            ndarray = np.array([array])
        elif len(ndarray.shape) > 2:
            raise ValueError(f"Cannot handle shape with more than 2 dimensions but got {ndarray.shape}")

        if hasattr(cls, "__size__") and cls.__size__ not in ndarray.shape:
            raise ValueError(f"Expected vector of size {cls.__size__} but got {ndarray.shape}")

        return cls(__root__=ndarray)

    @classmethod
    def validate(cls, v):
        if isinstance(v, dict):
            return cls.array(list(v.values()))

        return cls.array(np.array(v))

    def dict(self, *args, **kwargs):
        return self.__root__.tolist()

    @classmethod
    def parse_obj(cls, obj: Any):
        return cls.array(obj)

    @classmethod
    def identity(cls, size: int):
        return cls.array(np.eye(size))

    def __getitem__(self, item):
        return self.__root__[item]

    def __eq__(self, other):
        return np.array_equal(self.__root__, Matrix.array(other).ndarray)

    def __len__(self):
        return len(self.__root__)

    def __iter__(self):
        return iter(self.__root__)

    def __str__(self):
        return str(self.__root__)

    def __repr__(self):
        return self.__str__()

    def __add__(self, other):
        return type(self).array(self.__root__ + np.array(other))

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        return type(self).array(self.__root__ - np.array(other))

    def __neg__(self):
        return type(self).array(-self.__root__)

    def __mul__(self, other):
        return type(self).array(self.__root__ * np.array(other))

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        return type(self).array(self.__root__ / np.array(other))

    def __rtruediv__(self, other):
        raise GeometryError(f"Cannot divide {type(other)} by a vector")

    def __matmul__(self, other):
        return Matrix.array(np.dot(self.__root__, Matrix.array(other).ndarray))

    def __rmatmul__(self, other):
        return other.__matmul__(self)

    def transpose(self):
        return Matrix.array(self.__root__.transpose())

    def dot(self, other):
        return np.dot(self.__root__, np.array(other).transpose())

    # TODO Move to BaseVector and create det
    def norm(self):
        return np.sqrt(self.dot(self))

    # TODO Move to BaseVector
    def normalize(self):
        return self / self.norm()

    def inverse(self):
        return Matrix.array(np.linalg.inv(self.__root__))


class VectorN(Matrix):
    pass


class Vector2(Matrix):
    __size__ = 2

    @property
    def x(self):
        return self.__root__[:, 0]

    @property
    def y(self):
        return self.__root__[:, 1]

    @classmethod
    def xy(cls, x, y):
        return cls.array([float(x), float(y)])


class Vector3(Matrix):
    __size__ = 3

    @property
    def x(self):
        return self.__root__[:, 0]

    @property
    def y(self):
        return self.__root__[:, 1]

    @property
    def z(self):
        return self.__root__[:, 2]

    @classmethod
    def xyz(cls, x, y, z):
        return cls.array([float(x), float(y), float(z)])

    def cross(self, other):
        other_vector = type(self).array(other)
        return type(self).xyz(
            x=self.y * other_vector.z - self.z * other_vector.y,
            y=self.z * other_vector.x - self.x * other_vector.z,
            z=self.x * other_vector.y - self.y * other_vector.x,
        )


class Vector4(Matrix):
    __size__ = 4

    @property
    def x(self):
        return self.__root__[:, 0]

    @property
    def y(self):
        return self.__root__[:, 1]

    @property
    def z(self):
        return self.__root__[:, 2]

    @property
    def w(self):
        return self.__root__[:, 3]

    @classmethod
    def wxyz(cls, x, y, z, w):
        return cls.array([float(x), float(y), float(z), float(w)])


class Point2(Vector2):
    pass


class Point3(Vector3):
    pass


class Coordinate(ValueObject):
    x: Vector3
    y: Vector3
    z: Vector3


class Dimension2(ValueObject):
    height: float
    width: float


class Dimension3(ValueObject):
    height: float
    width: float
    depth: float


class Rect2(ValueObject):
    min: Point2
    max: Point2


class Rotation3(ValueObject):
    __root__: SciPyRotation3

    @property
    def quaternion(self):
        return Vector4.array(self.__root__.as_quat())

    @property
    def matrix(self):
        return Matrix.array(self.__root__.as_matrix()[0, :, :])

    @property
    def euler(self):
        return Vector3.array(self.__root__.as_euler("xyz"))

    @classmethod
    def identity(cls):
        return cls.array([0, 0, 0, 1])

    @classmethod
    def array(cls, array):
        if isinstance(array, cls):
            return array
        elif isinstance(array, SciPyRotation3):
            return cls(__root__=array)

        ndarray = np.array(array)
        if len(ndarray.shape) == 1:
            ndarray = np.array([array])
        elif len(ndarray.shape) > 2:
            raise ValueError(f"Cannot handle shape with more than 2 dimensions but got {ndarray.shape}")

        m = min(ndarray.shape)
        n = max(ndarray.shape)
        if m == 1 and n == 4:
            return cls(__root__=SciPyRotation3.from_quat(ndarray))
        elif m == 1 and n == 3:
            return cls(__root__=SciPyRotation3.from_euler("xyz", ndarray))
        elif m == 3 and n == 3:
            return cls(__root__=SciPyRotation3.from_matrix(ndarray))

        raise ValueError(f"Cannot handle shape of dimensions {ndarray.shape}")

    @classmethod
    def validate(cls, v):
        return cls.array(v)

    def dict(self, *args, **kwargs):
        return self.__root__.as_quat().tolist()

    @classmethod
    def parse_obj(cls, obj: Any):
        return cls.array(obj)

    def __getitem__(self, item):
        return self.__root__[item]

    def __eq__(self, other):
        return self.__root__ == type(self).array(other).__root__

    def __len__(self):
        return 4

    def __iter__(self):
        return iter(self.__root__.as_quat())

    def __str__(self):
        return str(self.__root__.as_quat())

    def __repr__(self):
        return self.__str__()

    def __mul__(self, other):
        return type(self).array(self.__root__ * type(self).array(other).__root__)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __matmul__(self, other):
        return self.matrix @ other

    def __rmatmul__(self, other):
        return other.__matmul__(self.__root__.as_matrix())


# TODO Overload operators?
class Pose3(ValueObject):
    position: Point3
    rotation: Rotation3

    @property
    def matrix(self):
        return Matrix.array(
            np.vstack(
                (
                    np.hstack(
                        (
                            self.rotation.matrix.ndarray,
                            self.position.ndarray.transpose(),
                        ),
                    ),
                    [0, 0, 0, 1],
                )
            )
        )
