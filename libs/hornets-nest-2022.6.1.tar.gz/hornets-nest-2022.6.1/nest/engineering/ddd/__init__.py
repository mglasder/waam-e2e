from abc import ABCMeta, abstractmethod
from typing import Generic, TypeVar

from nest.engineering.utils.logger import LoggerMixin
from nest.engineering.utils.pydantic import BaseModel


class ValueObject(BaseModel, metaclass=ABCMeta):
    def update(self, **kwargs):
        return self.copy(update=kwargs)

    class Config:
        allow_mutation = False


class Aggregate(BaseModel, metaclass=ABCMeta):
    class Config:
        allow_mutation = True
        validate_assignment = True


# TODO Remove and use AppService from Application instead
class Service(LoggerMixin, metaclass=ABCMeta):
    # TODO Replace by on_startup
    def start(self):
        """
        Hook executed after the service has been created
        """
        pass

    # TODO Replace by on_shutdown
    def stop(self):
        """
        Hook executed after the service has been created
        """
        pass

    def on_startup(self, *args, **kwargs):
        """
        Hook executed after the service has been created.
        All the arguments will be injected.
        """
        pass

    def on_shutdown(self, *args, **kwargs):
        """
        Hook executed after the service has been created.
        All the arguments will be injected.
        """
        pass


BuildType = TypeVar("BuildType")


class Builder(Generic[BuildType], LoggerMixin, metaclass=ABCMeta):
    @abstractmethod
    def build(self) -> BuildType:
        raise NotImplementedError
