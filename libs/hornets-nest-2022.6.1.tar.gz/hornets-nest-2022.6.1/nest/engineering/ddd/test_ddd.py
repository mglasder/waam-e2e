import pytest
from assertpy import assert_that

from nest.engineering.ddd import ValueObject


class SomeValueObject(ValueObject):
    name: str


class TestCase:
    @pytest.fixture
    def some_value_object(self):
        return SomeValueObject(name="Something")

    def test_has_value(self, some_value_object):
        assert_that(some_value_object).has_name("Something")
