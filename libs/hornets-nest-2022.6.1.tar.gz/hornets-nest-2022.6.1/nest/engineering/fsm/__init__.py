from abc import ABCMeta
from typing import Generic, Type, TypeVar

from nest.engineering.utils.logger import LoggerMixin
from nest.engineering.utils.typing import find_methods_with_attribute, get_class_name


def on_enter(func):
    func.enter = True
    return func


def on_exit(func):
    func.exit = True
    return func


FsmControllerType = TypeVar("FsmControllerType", bound="FsmController")


class FsmState(Generic[FsmControllerType], LoggerMixin, metaclass=ABCMeta):
    ctrl: FsmControllerType

    @property
    def store(self):
        return self.ctrl.store

    def change_state(self, cls: Type["FsmState"], *args, **kwargs):
        return self.ctrl.change_state(cls, *args, **kwargs)


class FsmStore(dict, object):
    def __init__(self):
        super().__init__()

    def __setattr__(self, key, value):
        self[key] = value

    def __getattr__(self, item):
        if item not in self:
            return None

        return self[item]

    def __delattr__(self, item):
        if item in self:
            del self[item]


class FsmController(LoggerMixin):
    _state: FsmState
    _default_state: Type[FsmState]
    store: FsmStore

    @classmethod
    def default(cls, state):
        if hasattr(cls, "_default_state"):
            raise ValueError(f"{cls._default_state} is already set as default")

        cls._default_state = state
        return state

    @property
    def state(self) -> FsmState:
        return self._state

    @state.setter
    def state(self, state: FsmState):
        self._state = state
        if state:
            self._state.ctrl = self

    def start(self, *args, **kwargs):
        if not hasattr(self, "_default_state"):
            raise ValueError(f"No state has been defined as default for {self}")

        self.store = FsmStore()

        state = self._default_state
        self.logger.info(f"Initializing with state {get_class_name(state)}")
        self.state = state(*args, **kwargs)
        self._enter_state()

    def change_state(self, state: Type[FsmState], *args, **kwargs):
        if isinstance(state, FsmState):
            raise ValueError(f"{state} is not an instance of {FsmState}")

        self.logger.info(f"Changing state from {get_class_name(self.state)} to {get_class_name(state)}")
        self._exit_state()
        self.state = state(*args, **kwargs)
        self._enter_state()

    def _enter_state(self):
        for method in find_methods_with_attribute(self.state, "enter"):
            self.logger.info(f"Entering {get_class_name(self.state)} with {method.__name__}")
            method()

    def _exit_state(self):
        for method in find_methods_with_attribute(self.state, "exit"):
            self.logger.info(f"Exiting {get_class_name(self.state)} with {method.__name__}")
            method()

    def stop(self):
        self.logger.info(f"Stopped from state {get_class_name(self.state)}")
        if self.state:
            self._exit_state()
            self.state = None

    def __contains__(self, state: Type[FsmState]):
        return isinstance(self.state, state)
