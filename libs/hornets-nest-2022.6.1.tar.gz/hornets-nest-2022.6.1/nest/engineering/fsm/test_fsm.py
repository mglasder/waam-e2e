import pytest
from assertpy import assert_that

from nest.engineering.fsm import FsmController, FsmState, on_enter, on_exit


class MockController(FsmController):
    def toggle(self):
        self.state.toggle()


@MockController.default
class MockStateA(FsmState):
    def toggle(self):
        self.change_state(MockStateB)


class MockStateB(FsmState):
    def toggle(self):
        self.change_state(MockStateA)


class MockStateC(FsmState):
    def toggle(self):
        pass

    @on_enter
    def enter(self):
        self.ctrl.change_state(MockStateB)

    @on_exit
    def exit(self):
        pass


@pytest.fixture
def ctrl():
    ctrl = MockController()
    ctrl.start()
    yield ctrl
    ctrl.stop()


def test_initialized(ctrl):
    assert_that(ctrl).contains(MockStateA)


def test_toggle(ctrl):
    ctrl.toggle()
    assert_that(ctrl).contains(MockStateB)


def test_double_toggle(ctrl):
    ctrl.toggle()
    assert_that(ctrl).contains(MockStateB)

    ctrl.toggle()
    assert_that(ctrl).contains(MockStateA)


def test_forward_state(ctrl):
    assert_that(ctrl).contains(MockStateA)
    ctrl.change_state(MockStateC)
    assert_that(ctrl).contains(MockStateB)


def test_no_default_state():
    class NoDefaultStateController(FsmController):
        pass

    with pytest.raises(ValueError):
        NoDefaultStateController().start()


def test_double_default_state():
    class DoubleDefaultStateController(FsmController):
        def toggle(self):
            self.state.toggle()

    @DoubleDefaultStateController.default
    class FirstDefaultState(FsmState):
        def toggle(self):
            self.change_state(MockStateB)

    with pytest.raises(ValueError):

        @DoubleDefaultStateController.default
        class SecondDefaultState(FsmState):
            def toggle(self):
                self.change_state(MockStateA)
