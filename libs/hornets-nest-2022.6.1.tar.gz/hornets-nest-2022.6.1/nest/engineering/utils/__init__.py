import importlib_resources


def path_from_package(package: str):
    """
    Retrieve the Path for the provided package
    """
    return importlib_resources.files(package)
