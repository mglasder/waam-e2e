from assertpy import assert_that

from nest.engineering.utils import yml


def test_serialize_and_deserialize(tmp_path):
    fixture = {
        "key": "value",
    }
    fixture_path = tmp_path / "test.yaml"

    fixture_yml = yml.dump(fixture, fixture_path)
    assert_that(fixture_yml).is_instance_of(str)

    fixture2 = yml.load(fixture_path)
    assert_that(fixture2).is_equal_to(fixture)
