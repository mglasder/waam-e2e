from asyncio import Queue
from typing import List

from nest.engineering.utils.logger import LoggerMixin


class AsyncEvent(LoggerMixin):
    def __init__(self):
        self._queues: List[Queue] = []

    def notify(self, obj=None):
        self.logger.debug("notify")
        for q in self._queues:
            q.put_nowait(obj)

        self._queues.clear()

    def __await__(self):
        self.logger.debug("__await__")
        queue = Queue(maxsize=1)
        self._queues.append(queue)
        return queue.get().__await__()
