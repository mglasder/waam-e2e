import pytest
from assertpy import assert_that

from nest.engineering.utils.pydantic import BaseModel, mutable


class SomeModel(BaseModel):
    value = 5

    class Config:
        allow_mutation = False


@pytest.mark.parametrize(
    "filename",
    [
        "test.json",
        "test.yml",
        "test.yaml",
        "test.pickle",
    ],
)
def test_write_and_read_file(tmp_path, filename):
    file_path = tmp_path / filename

    model = SomeModel()
    model.write_file(file_path)

    model2 = SomeModel.read_file(file_path)
    assert_that(model2).is_equal_to(model)


def test_cannot_parse_yml_file(tmp_path):
    file_path = tmp_path / "test.yaml"
    file_path.touch()

    with pytest.raises(TypeError):
        SomeModel.read_file(file_path)


def test_mutable_override():
    _SomeModel = mutable(SomeModel)

    model = _SomeModel()
    model.value = 6

    assert_that(model.value).is_equal_to(6)
