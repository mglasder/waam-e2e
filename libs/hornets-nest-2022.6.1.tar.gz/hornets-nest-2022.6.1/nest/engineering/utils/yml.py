from pathlib import Path
from typing import Union

import yaml

try:
    from yaml import CDumper as Dumper
    from yaml import CLoader as Loader
except ImportError:  # noqa
    from yaml import Dumper, Loader


def loads(stream):
    return yaml.load(
        stream,
        Loader=Loader,
    )


def load(path: Union[Path, str]):
    with open(path) as fp:
        return loads(fp.read())


def dumps(data, stream=None, **kwargs) -> Union[None, str]:
    return yaml.dump(
        data,
        stream,
        Dumper=Dumper,
        **kwargs,
    )


def dump(data, path: Union[Path, str], stream=None, **kwargs):
    with open(path, "w") as fp:
        yml_str = dumps(data)
        fp.write(yml_str)
        return yml_str
