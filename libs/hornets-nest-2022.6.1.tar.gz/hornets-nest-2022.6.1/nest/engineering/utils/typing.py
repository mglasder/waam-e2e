from typing import Any, Optional, Union, get_args


def get_generic_type(cls, param_number=0):
    if not isinstance(cls, type):
        cls = type(cls)

    for orig_base in cls.__orig_bases__:
        args = get_args(orig_base)
        if args:
            return args[param_number]


def get_class_path(name_class_or_object: Optional[Union[str, Any]] = None):
    if not name_class_or_object:
        return None

    if isinstance(name_class_or_object, str):
        return name_class_or_object

    if isinstance(name_class_or_object, type):
        return f"{name_class_or_object.__module__}.{name_class_or_object.__name__}"

    return f"{name_class_or_object.__module__}.{name_class_or_object.__class__.__name__}"


def get_class_name(obj: Union[str, type, object]):
    if obj is None or isinstance(obj, str):
        return obj

    if isinstance(obj, type):
        return obj.__name__

    return obj.__class__.__name__


def find_methods_with_attribute(obj: object, attribute: str):
    for method in [getattr(obj, name) for name in dir(obj)]:
        if hasattr(method, attribute) and getattr(method, attribute) is True:
            yield method
