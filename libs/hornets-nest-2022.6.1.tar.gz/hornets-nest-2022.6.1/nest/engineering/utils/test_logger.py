import logging

from assertpy import assert_that

from nest.engineering.utils.logger import Logger, logger


class MockLogHandler(logging.Handler):
    records = []

    def emit(self, record):
        self.records.append(record)


class Something:
    logger = Logger()

    def abcde(self):
        return "a"


class SomethingMore(Something):
    pass


@logger
class TestCase:
    def test_something(self):
        handler = MockLogHandler()
        logging.root.addHandler(handler)

        something = Something()
        self.logger.warning("warning")
        something.logger.info("info")
        something.logger.debug("debug")
        Something.logger.info("info")
        SomethingMore.logger.warning("warning")

        # Debug is supposed to be ignored
        assert_that(handler.records).is_length(4)
