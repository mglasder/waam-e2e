import logging
from logging.config import dictConfig
from typing import Any, Optional, Union

# https://docs.python.org/3/library/logging.config.html
from nest.engineering.utils.typing import get_class_path


# TODO Add matplotlib as warning
def simple_logging_config(handler_name: str, handler_dict: dict, level=logging.INFO):
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "simple": {
                "format": "%(asctime)s - %(threadName)s - %(levelname)s - %(name)s - %(message)s",
            },
        },
        "handlers": {
            handler_name: handler_dict,
        },
        "root": {
            "handlers": [handler_name],
            "level": level,
        },
    }


LOGGING_CONFIG = simple_logging_config(
    "console",
    {
        "class": "logging.StreamHandler",
        "formatter": "simple",
    },
    level=logging.INFO,
)

# TODO Try to load config file in current directory before using the default config
dictConfig(LOGGING_CONFIG)


def get_logger(name_class_or_object: Optional[Union[str, Any]] = None):
    if not name_class_or_object:
        return logging.getLogger()

    return logging.getLogger(get_class_path(name_class_or_object))


class Logger(object):
    def __get__(self, instance, instance_type):
        return get_logger(instance or instance_type)


def logger(cls):
    setattr(cls, "logger", Logger())
    return cls


class LoggerMixin:
    logger = property(get_logger)
