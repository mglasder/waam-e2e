import pytest
from assertpy import assert_that

from nest.engineering.utils.events import AsyncEvent


@pytest.mark.asyncio
async def test_async(event_loop):
    expected_value = "Something"

    event = AsyncEvent()

    event_loop.call_later(1, event.notify, expected_value)

    value = await event

    assert_that(value).is_equal_to(expected_value)
