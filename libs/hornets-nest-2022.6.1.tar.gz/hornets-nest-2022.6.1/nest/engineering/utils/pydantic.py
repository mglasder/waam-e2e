import gzip
import pickle
from abc import ABCMeta
from pathlib import Path
from typing import TYPE_CHECKING, Type, TypeVar, Union

import msgpack

if TYPE_CHECKING:
    from pydantic.typing import AbstractSetIntStr, MappingIntStrAny

import orjson
from pydantic import BaseModel as PydanticBaseModel
from pydantic import BaseSettings as PydanticBaseSettings

from nest.engineering.utils import yml


def orjson_dumps(v, *, default):
    # orjson.dumps returns bytes, to match standard json.dumps we need to decode
    return orjson.dumps(v, default=default).decode()


def yaml_dumps(v, **kwargs):
    # orjson.dumps returns bytes, to match standard json.dumps we need to decode
    return yml.dumps(v, **kwargs).encode()


loaders = {
    "json": orjson.loads,
    "yml": yml.loads,
    "yaml": yml.loads,
    "pickle": pickle.loads,
    "msgp": msgpack.loads,
}

dumpers = {
    "json": orjson.dumps,
    "yml": yaml_dumps,
    "yaml": yaml_dumps,
    "pickle": pickle.dumps,
    "msgp": msgpack.dumps,
}

encoders = {
    "gz": gzip.compress,
}

decoders = {
    "gz": gzip.decompress,
}


def identity(obj):
    return obj


class LoaderException(Exception):
    pass


ModelType = TypeVar("ModelType", bound=PydanticBaseModel)


class PydanticYamlMixin(metaclass=ABCMeta):
    @classmethod
    def read_file(cls: Type[ModelType], path: Union[Path, str]) -> ModelType:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(str(path))

        extension = path.name.split(".")[-1]

        decoder = identity
        if extension in decoders:
            decoder = decoders[extension]
            extension = path.name.split(".")[-2]

        if extension not in loaders:
            raise LoaderException(f"No loader registered for extension {extension}")

        loader = loaders[extension]

        try:
            with path.open("rb") as f:
                obj = loader(decoder(f.read()))
                return cls.parse_obj(obj)

        except Exception as ex:
            raise TypeError(f"Could not parse {cls} from {path}") from ex

    def write_file(
        self,
        path: Union[Path, str],
        *,
        include: Union["AbstractSetIntStr", "MappingIntStrAny"] = None,
        exclude: Union["AbstractSetIntStr", "MappingIntStrAny"] = None,
        by_alias: bool = False,
        skip_defaults: bool = None,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
        **kwargs,
    ):
        path = Path(path)
        extension = path.name.split(".")[-1]
        encoder = identity
        if extension in decoders:
            encoder = encoders[extension]
            extension = path.name.split(".")[-2]

        if extension not in loaders:
            raise LoaderException(f"No dumper registered for extension {extension}")

        dumper = dumpers[extension]

        obj = self.dict(
            include=include,
            exclude=exclude,
            by_alias=by_alias,
            skip_defaults=skip_defaults,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )

        try:
            with path.open("wb") as f:
                obj_str = encoder(dumper(obj, **kwargs))
                return f.write(obj_str)

        except Exception as ex:
            raise TypeError(f"Could not dump {self} into {path}") from ex


class BaseModel(PydanticBaseModel, PydanticYamlMixin):
    class Config:
        json_loads = orjson.loads
        json_dumps = orjson_dumps
        arbitrary_types_allowed = True


class BaseSettings(PydanticBaseSettings, PydanticYamlMixin):
    class Config:
        json_loads = orjson.loads
        json_dumps = orjson_dumps
        arbitrary_types_allowed = True


BaseModelType = TypeVar("BaseModelType", bound=BaseModel)


def mutable(cls: Type[BaseModelType]) -> Type[BaseModelType]:
    class _Mutable(cls):
        class Config:
            allow_mutation = True

    _Mutable.__name__ = f"Mutable{cls.__name__}"
    _Mutable.__qualname__ = f"Mutable{cls.__qualname__}"

    return _Mutable
