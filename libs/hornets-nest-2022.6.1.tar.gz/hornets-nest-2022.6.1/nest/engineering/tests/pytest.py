import asyncio
import os
from typing import IO, Any, Mapping, Optional, Sequence, Text, Union

import numpy as np
import pytest
from assertpy import add_extension, assert_that
from typer.testing import CliRunner

from nest.engineering.app import Application


@pytest.fixture
def tmp_pwd(tmp_path):
    current_path = os.getcwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(current_path)


@pytest.fixture
def cli_runner(tmp_pwd):
    runner = CliRunner()

    def wrapper(
        app: Application,
        args: Optional[Union[str, Sequence[str]]] = None,
        input: Optional[Union[bytes, Text, IO[Any]]] = None,
        env: Optional[Mapping[str, str]] = None,
        catch_exceptions: bool = True,
        color: bool = False,
        **extra: Any,
    ):
        async def _async_invoke():
            result = runner.invoke(
                app.cli,
                args=args,
                input=input,
                env=env,
                catch_exceptions=catch_exceptions,
                color=color,
                **extra,
            )
            return result

        return asyncio.run(_async_invoke(), debug=True)

    return wrapper


def is_cli_success(self):
    if self.val.exception:
        raise self.val.exception

    assert_that(self.val.exit_code).is_equal_to(0)


def is_close_to(self, other, tolerance):
    if not np.allclose(self.val, other, tolerance):
        self.error(f"Expected <{self.val}> to be close to <{other}> within tolerance <{tolerance}>, but was not.")

    return self


add_extension(is_cli_success)
add_extension(is_close_to)
