import os
from distutils.command.build_ext import build_ext
from pathlib import Path

from Cython.Build import cythonize


def build(setup_kwargs):
    # gcc arguments hack: enable optimizations
    os.environ["CFLAGS"] = "-O3"

    # Find all pyx
    module_list = []
    for p in setup_kwargs["packages"]:
        module_list.extend([str(f) for f in Path(p).glob("**/*.pyx")])

    # Build
    version = setup_kwargs["version"]

    def convert_relative_dependency(dependency: str):
        if "@" in dependency:
            dep_name = dependency.split("@")[0].strip()
            return f"{dep_name}=={version}"

        return dependency

    setup_kwargs.update(
        {
            "ext_modules": cythonize(
                module_list,
                language="c++",
                build_dir="build",
                language_level=3,
                compiler_directives={"linetrace": True},
            ),
            "cmdclass": {
                "build_ext": build_ext,
            },
            "options": {
                "build_ext": {
                    "inplace": True,
                }
            },
            "install_requires": [convert_relative_dependency(ir) for ir in setup_kwargs["install_requires"]],
        }
    )
