# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nest',
 'nest.analytics',
 'nest.automation',
 'nest.automation.robots',
 'nest.automation.robots.abb',
 'nest.automation.sensors',
 'nest.automation.sensors.creaform',
 'nest.automation.sensors.creaform.dlls',
 'nest.automation.sensors.creaform.targets',
 'nest.automation.sensors.flir',
 'nest.automation.sensors.flir.fixtures',
 'nest.automation.sensors.gocator',
 'nest.automation.sensors.gocator.dlls',
 'nest.automation.sensors.proges',
 'nest.engineering',
 'nest.engineering.app',
 'nest.engineering.config',
 'nest.engineering.ddd',
 'nest.engineering.fsm',
 'nest.engineering.geometry',
 'nest.engineering.tests',
 'nest.engineering.utils']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'fastapi>=0.78.0,<0.79.0',
 'importlib-resources>=5.4.0,<6.0.0',
 'matplotlib>=3.5.1,<4.0.0',
 'msgpack>=1.0.3,<2.0.0',
 'numpy>=1.22.1,<2.0.0',
 'orjson>=3.6.5,<4.0.0',
 'pydantic>=1.8.2,<2.0.0',
 'scipy>=1.7.3,<2.0.0',
 'typer>=0.4.1,<0.5.0',
 'uvicorn>=0.17.6,<0.18.0',
 'vtk>=9.1.0,<10.0.0']

entry_points = \
{'console_scripts': ['creaform = nest.automation.sensors.creaform.app:app.cli',
                     'flir = nest.automation.sensors.flir.app:app.cli',
                     'gocator = nest.automation.sensors.gocator.app:app.cli',
                     'proges = nest.automation.sensors.proges.app:app.cli']}

setup_kwargs = {
    'name': 'hornets-nest',
    'version': '2022.6.1',
    'description': '',
    'long_description': None,
    'author': 'Thomas Denoreaz',
    'author_email': 'denoreaz@inspire.ethz.ch',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<3.11',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
